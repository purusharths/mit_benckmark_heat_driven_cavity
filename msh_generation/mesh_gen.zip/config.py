xsize = 50
ysize = 100
alpha = 0.025